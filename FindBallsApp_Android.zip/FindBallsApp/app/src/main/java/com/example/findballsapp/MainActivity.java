package com.example.findballsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//import android.widget.ImageView;
import android.widget.ViewFlipper;


public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    Button button_prev,button_next;
    //ImageView imageView;
//    int[] images ={R.drawable.americanfootball,R.drawable.football,R.drawable.shuttlecock};
    ViewFlipper views;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // imageView=(ImageView) findViewById(R.id.football_image);
        views = (ViewFlipper) findViewById(R.id.viewFlipper);
        button_prev = (Button) findViewById(R.id.button_prev);
        button_next=(Button) findViewById(R.id.button_next);
        button_next.setOnClickListener(this);
        button_prev.setOnClickListener(this);

    }
    @Override
    public void onClick(View view)
    {
        if(view==button_next)
        {
            views.showNext();
        }
        else if (view==button_prev) {
            views.showPrevious();
        }
    }
}